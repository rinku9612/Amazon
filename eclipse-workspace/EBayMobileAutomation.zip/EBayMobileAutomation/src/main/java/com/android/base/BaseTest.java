package com.android.base;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;

import com.android.utils.TestUtils;
import com.aventstack.extentreports.testng.listener.ExtentITestListenerAdapter;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.FindsByAndroidUIAutomator;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

@Listeners(ExtentITestListenerAdapter.class)
public class BaseTest {
	@SuppressWarnings("rawtypes")
	protected static AppiumDriver driver;
	protected static Properties props;
	protected static String dateTime;
	TestUtils utils;
	protected HashMap<String, String> strings = new HashMap<String, String>();
	public static Logger log = LogManager.getLogger(BaseTest.class.getName());
	InputStream inputStream;
	InputStream stringsis;

	public BaseTest() {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@SuppressWarnings("rawtypes")
	@Parameters({ "platformName", "platformVersion", "deviceName" })
	@BeforeTest
	public void beforeTest(String platformName, String platformVersion, String deviceName) throws Exception {

		utils = new TestUtils();
		dateTime = utils.dateTime();
		try {
			props = new Properties();
			String propsFileName = "config.properties";
			String xmlfileName = "Strings/strings.xml";
			inputStream = getClass().getClassLoader().getResourceAsStream(propsFileName);
			props.load(inputStream);
			stringsis = getClass().getClassLoader().getResourceAsStream(xmlfileName);
			strings = utils.parseStringXML(stringsis);
			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
			desiredCapabilities.setCapability("platformName", platformName);
			desiredCapabilities.setCapability("platformVersion", platformVersion);
			desiredCapabilities.setCapability("deviceName", deviceName);
			desiredCapabilities.setCapability("automationName", props.getProperty("androidAutomationName"));

			desiredCapabilities.setCapability("UDID", "7a86cce6");
			desiredCapabilities.setCapability("appPackage", props.getProperty("androidAppPackage"));
			desiredCapabilities.setCapability("appActivity", props.getProperty("androidAppActivity"));
//		  String appUrl=getClass().getClassLoader().getResource(props.getProperty("androidAppLocation	"));
//		  desiredCapabilities.setCapability("app",appUrl);

			URL url = new URL(props.getProperty("appiumURL"));
			driver = new AndroidDriver(url, desiredCapabilities);
			@SuppressWarnings("unused")
			String sessionId = driver.getSessionId().toString();

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			log.info("Amazon app Launched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
			if (stringsis != null) {
				stringsis.close();
			}
		}

	}

	public void waitForVisibility(MobileElement e) {
		WebDriverWait wait = new WebDriverWait(driver, TestUtils.WAIT);
		try {
			wait.until(ExpectedConditions.visibilityOf(e));
		} catch (StaleElementReferenceException e1) {
			wait.until(ExpectedConditions.visibilityOf(e));

		}
	}

	public void waitForVisibility(List<MobileElement> e, String ele) {
		WebDriverWait wait = new WebDriverWait(driver, TestUtils.WAIT);
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id(ele)));
	}

	public void click(MobileElement e) {
		waitForVisibility(e);
		e.click();
	}

	public void sendKeys(MobileElement e, String txt) {
		waitForVisibility(e);
		e.sendKeys(txt);

	}

	public String getAttribute(MobileElement e, String attribute) {
		waitForVisibility(e);
		return e.getAttribute(attribute);

	}

	public String getText(MobileElement e) {
		String txt = null;
		txt = getAttribute(e, "text");
		System.out.println(txt);
		return txt;

	}

	@SuppressWarnings("rawtypes")
	public void scrollAndClick(String visibleText) {
		((FindsByAndroidUIAutomator) driver).findElementByAndroidUIAutomator(
				"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
						+ visibleText + "\").instance(0))")
				.click();
	}

	@SuppressWarnings("unchecked")
	public static void scroll(String visibleText) {
		((FindsByAndroidUIAutomator<MobileElement>) driver).findElementByAndroidUIAutomator(
				"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\""
						+ visibleText + "\").instance(0))");
	}

	@SuppressWarnings("rawtypes")
	public MobileElement scrollToElement() {
		return (MobileElement) ((FindsByAndroidUIAutomator) driver)
				.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()"
						+ ".scrollable(true)).scrollIntoView(" + "new UiSelector().text(\"Add to Cart\"));");

	}

	public void quitDriver() {

	}

	@SuppressWarnings("rawtypes")
	public AppiumDriver getDriver() {
		return driver;
	}

	public String getDateTime() {
		return dateTime;
	}

}
