package com.android.base;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class MenuPage extends BaseTest{
	@AndroidFindBy(xpath="//android.widget.ImageView[@content-desc='Navigation panel, button, double tap to open side panel']")
	private MobileElement settingsBtn;
	
	@AndroidFindBy(id="action_bar_burger_icon")
	private MobileElement menubar;
	
	@AndroidFindBy(id = "gno_greeting_text_view")
	private MobileElement greetingText;
	
	
	public String greetingText() {
		waitForVisibility(menubar);
		click(menubar);
		waitForVisibility(greetingText);
		String greetingTxt=getAttribute(greetingText, "text");
		return greetingTxt;
	}

}
