package com.app.pages;

import java.util.List;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SearchResultPage extends BaseTest{

	@AndroidFindBy(xpath ="//android.widget.TextView[contains(@text,'65A082U')]")
	private MobileElement selectProd;
	
	@AndroidFindBy(id = "list_product_linear_layout")
	private List<MobileElement> listProducts;
	
	public ProductPage selectProduct() {
		waitForVisibility(selectProd);
		click(selectProd);
		return new ProductPage();
	}
	
	public ProductPage selectProductList() {
		waitForVisibility(listProducts, "list_product_linear_layout");
		scroll("65A082U");
		click(selectProd);
		return new ProductPage();
	}
		
	}
	

	


