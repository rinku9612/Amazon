package com.app.pages;

import java.util.List;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class ProductPage extends BaseTest {

	@AndroidFindBy(xpath = "//android.widget.EditText[contains(@text,'rupees')]")
	private MobileElement price;
	@AndroidFindBy(xpath = "//android.view.View[contains(@text,'Sanyo 165 cm (65 inches)')]")
	private MobileElement tvDesc;
	
	@AndroidFindBy(id = "list_product_linear_layout")
	private List<MobileElement> listProducts;
	
	@AndroidFindBy(xpath = "//android.widget.Button[contains(@resource-id,'add-to-cart-button')]")
	private MobileElement addToCart;
	
	@AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc,'Cart')]")
	private MobileElement showCart;
	
	public String getPrice() {
		return getText(price);
	}
	public String getProductDesc() {
		return getText(tvDesc);
	}
	
	
	public void addToCart() {
		scroll("Add to Cart");
		click(addToCart);
	}
	/*
	 * public String addToCart(MobileElement e) {
	 * 
	 * MobileElement element = scrollToElement(); element.click(); return
	 * getText(addToCart);
	 * 
	 * }
	 */
	
	public CartPage showCart() {
		click(showCart);
		return new CartPage();
	}
}
