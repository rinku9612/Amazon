package com.app.pages;

public class SettingsPage {

}
