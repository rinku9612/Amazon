package com.app.pages;

import com.android.base.BaseTest;
import com.google.common.collect.ImmutableMap;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;


public class LandingPage extends BaseTest {

	@AndroidFindBy(id="rs_search_src_text")
	private MobileElement searchTxtBox;
	
	@AndroidFindBy(id="action_bar_burger_icon")
	private MobileElement menubar;
	
	@AndroidFindBy(id = "gno_greeting_text_view")
	private MobileElement greetingText;
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Home')]")
	private MobileElement homeBtn;
	
	//============= Method to enter item for search
	public SearchResultPage searchItem(String item) {
		waitForVisibility(searchTxtBox);
		click(searchTxtBox);
		sendKeys(searchTxtBox, item);
		driver.executeScript("mobile:performEditorAction", ImmutableMap.of("action", "Search"));
		return new SearchResultPage();		
	}
	
	public String clickMenubar() {
		waitForVisibility(menubar);
		click(menubar);
		return getText(greetingText);
	}
	public void clickHome() {
		click(homeBtn);
	}
}
