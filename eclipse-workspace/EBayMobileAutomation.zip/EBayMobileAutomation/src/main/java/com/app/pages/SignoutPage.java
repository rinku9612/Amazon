package com.app.pages;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SignoutPage extends BaseTest{

	@AndroidFindBy(id="android:id/message")
	private MobileElement message;
	
	@AndroidFindBy(id = "android:id/button2")
	private MobileElement signout;
	
	public void signout() {
		waitForVisibility(signout);
		click(signout);
	}
	
	public String getMessage() {
		waitForVisibility(message);
		return getAttribute(message, "text");
	}
}
