package com.app.pages;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class SignInPage extends BaseTest {

//***********************************Element SignIn****************************	
	@AndroidFindBy(id = "com.amazon.mShop.android.shopping:id/sign_in_button")
	private MobileElement signInBtn;

//*************Method for click on sign in Element SignIn****************************	
	public UsernamePage pressSigninBtn() {
		click(signInBtn);
		return new UsernamePage();
	}

	public boolean display() {
		if (signInBtn.isDisplayed()) {
			System.out.println("Redirected to signIn Page");
		}
		return true;
	}

}
