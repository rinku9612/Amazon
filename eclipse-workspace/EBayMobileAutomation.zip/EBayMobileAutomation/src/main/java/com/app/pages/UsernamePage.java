package com.app.pages;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class UsernamePage extends BaseTest {

	@AndroidFindBy(xpath = "//android.widget.EditText[contains(@resource-id,'ap_email_login')]")
	private MobileElement usernameTxtFld;
	
	@AndroidFindBy(xpath = "//android.widget.Button[contains(@resource-id,'continue')]")
	private MobileElement continueBtn;
	
	//========================== Method to Enter username
	public UsernamePage enterUserName(String userName) {
		waitForVisibility(usernameTxtFld);
		sendKeys(usernameTxtFld, userName);
		return this;
	}

   //============================ Method to click continue	
	public PasswordPage clickContinue() {
		click(continueBtn);
		return new PasswordPage();
	}

}
