package com.app.pages;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class CartPage extends BaseTest{
	
	@AndroidFindBy(xpath = "//android.widget.TextView[@text='1']")
	private MobileElement noOfProdInCart;
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Sanyo 165 cm (65 inches) ')]")
	private MobileElement prodInCart;
	@AndroidFindBy(xpath = "//android.view.View[contains(@text,'���54,999.00')]")
	private MobileElement priceInCart;

	@AndroidFindBy(id="action_bar_burger_icon")
	private MobileElement menubar;
	
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Settings')]")
	private MobileElement settings;
	@AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Not rohit kumar? Sign out')]")
	private MobileElement signout;
	
	public String itemQuantityInCart() {
		return getText(noOfProdInCart);
	}
	public String itemPriceInCart() {
		return getText(priceInCart);
	}
	public String itemNameInCart() {
		return getText(prodInCart);
	}
	
	public void clickMenuBar() {
		
		waitForVisibility(menubar);
		click(menubar);
	}
	public void clickSettings() {
		waitForVisibility(settings);
		click(settings);
	}
	public SignoutPage signOut() {
		waitForVisibility(signout);
		click(signout);
		return new SignoutPage();
	}
}
