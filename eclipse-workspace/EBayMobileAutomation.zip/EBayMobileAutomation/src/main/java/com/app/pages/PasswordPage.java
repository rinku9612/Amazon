package com.app.pages;

import com.android.base.BaseTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class PasswordPage extends BaseTest {
	
	
	@AndroidFindBy(xpath = "//android.widget.EditText[contains(@resource-id,'ap_password')]" )
	private MobileElement passwordTxtFld; 
	
	@AndroidFindBy(xpath = "//android.widget.Button[contains(@resource-id,'signInSubmit')]" )
	private MobileElement submitBtn; 
	
	//==================== Method to enter password
	public PasswordPage enterPassword(String password) {
		waitForVisibility(passwordTxtFld);
		sendKeys(passwordTxtFld,password);
		return this;
	}
	//==================== Method to click submit Button
	public LandingPage pressSubmitBtn() {
		
		click(submitBtn);
		return new LandingPage();
	}
}


