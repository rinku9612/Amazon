package com.app.scripts;

import java.io.InputStream;
import java.lang.reflect.Method;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.android.base.BaseTest;
import com.android.base.MenuPage;
import com.app.pages.CartPage;
import com.app.pages.LandingPage;
import com.app.pages.PasswordPage;
import com.app.pages.ProductPage;
import com.app.pages.SearchResultPage;
import com.app.pages.SignInPage;
import com.app.pages.SignoutPage;
import com.app.pages.UsernamePage;

public class AnazonShoppingTest extends BaseTest {
	SignInPage signinPage;
	UsernamePage usernamePage;
	PasswordPage passwordPage;
	LandingPage landingPage;
	SearchResultPage resultsPage;
	ProductPage productPage;
	CartPage showCartDetails;
	SignoutPage signoutPage;
	MenuPage menupage;

	
	JSONObject loginUsers;
	JSONTokener tokener;

	@BeforeClass
	public void beforeClass() throws Exception {
		InputStream datais=null;
		try {
			String dataFileName = "data/loginUsers.json";
			datais = getClass().getClassLoader().getResourceAsStream(dataFileName);
			JSONTokener tokener = new JSONTokener(datais);
			loginUsers = new JSONObject(tokener);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (datais !=null) {
				datais.close();
			}
		}
	}

	@AfterClass
	public void afterClass() {
		quitDriver();

	}

	@BeforeMethod
	public void beforeMethod(Method m) {
		signinPage = new SignInPage();
		log.info("Test Execution started");
		System.out.println("\n" + "=== Starting Test : " + m.getName() + "===" + "\n");
	}

	@AfterMethod
	public void afterMethod() {
		log.info("\n" +"=== Test execution stopped ===" + "\n");
	}

	@Test
	public void amazonTvPurchaseTest() throws InterruptedException {

		usernamePage = signinPage.pressSigninBtn();
		log.info("clicked on signin button");
		
		usernamePage.enterUserName(loginUsers.getJSONObject("validUser").getString("username"));
		log.info("Entered userName in username textfield");
		
		passwordPage = usernamePage.clickContinue();
		log.info("clicked on continue button");
		
		passwordPage.enterPassword(loginUsers.getJSONObject("validUser").getString("password"));
		log.info("Entered password in password textfield");
		
		landingPage = passwordPage.pressSubmitBtn();
		log.info("clicked on submit button");
		log.info("Redirected to landing page");
		
		String expectedGreetingMessage=strings.get("greetingText");
		String actualGreetingMessage=landingPage.clickMenubar();
		Assert.assertTrue(actualGreetingMessage.contains(expectedGreetingMessage), expectedGreetingMessage);
		log.info("Login succesfull,welcome message validated");
		landingPage.clickHome();

		resultsPage=landingPage.searchItem(loginUsers.getJSONObject("validUser").getString("searchItem"));
		log.info("Entered product in search box");
		
		productPage=resultsPage.selectProductList();
		String actualProduct=productPage.getProductDesc();
		String expectProduct=strings.get("products_page_tv_title");
		Assert.assertEquals(actualProduct, expectProduct);
		log.info("Selected product:"+actualProduct);
		log.info("Price of selected product:"+productPage.getPrice());
//		productPage.scrollToElement();
		
		productPage.addToCart();
		log.info("1 item succesfully added to cart");
		
		showCartDetails=productPage.showCart();
		String actualItemInCart=showCartDetails.itemNameInCart();
		String expectedItemInCart=strings.get("cart_details_page_tv_title");
		Assert.assertEquals(actualItemInCart, expectedItemInCart);
		log.info("Item selected and item in cart is same");
		
		String actualpriceInCart=showCartDetails.itemPriceInCart();
		String expectedpriceInCart=strings.get("cart_details_page_tv_price");
		Assert.assertEquals(actualpriceInCart, expectedpriceInCart);
		log.info("The price is same : Item selected and item in cart");
		
		String actualQuatityInCart=showCartDetails.itemQuantityInCart();
		String expectedQuatityInCart=strings.get("cart_details_page_tv_quantity");
		Assert.assertEquals(actualQuatityInCart, expectedQuatityInCart);
		log.info("The quantity of item selected is same in cart");
		
		showCartDetails.clickMenuBar();
		log.info("clicked on menubar");
		
		showCartDetails.clickSettings();
		log.info("clicked on settings");
		
		signoutPage=showCartDetails.signOut();
		log.info("clicked on signout");
		
		String signoutmsg=signoutPage.getMessage();
		log.info("Signout message:"+signoutmsg);
		
		signoutPage.signout();
		log.info("Signout Sucessfull");
		Assert.assertTrue(signinPage.display());
	}
}
